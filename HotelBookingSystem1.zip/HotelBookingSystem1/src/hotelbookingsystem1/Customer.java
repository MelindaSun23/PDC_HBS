/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelbookingsystem1;

public class Customer extends Person {

    public Customer(String name, String email, String phone, String address) {
        super(name, email, phone, address);
    }
}
